﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelloCode : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int love = 50;

        if (love > 90)
        {
            Debug.Log("트루엔딩");
        }

        else if(love > 70)
        {
            Debug.Log("굿엔딩");
        }
        else
        {
            Debug.Log("배드엔딩");
        }
    }

    
    // Update is called once per frame
    void Update()
    {
        
    }
}
