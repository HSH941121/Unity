﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zoo : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        Animal Tom = new Animal();
        Tom.name = "Tom";
        Tom.sound = "냐옹";

        Animal Jerry = new Animal();
        Jerry.name = "Jerry";
        Jerry.sound = "찍찍";

        Jerry = Tom;
        Jerry.name = "미키";

        Jerry.PlaySound();
        Tom.PlaySound();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
